-- --------------------------------------------------------
-- Host:                         localhost
-- Server version:               5.7.21 - MySQL Community Server (GPL)
-- Server OS:                    Win32
-- HeidiSQL Version:             9.4.0.5125
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping structure for table timeless.bible_books
CREATE TABLE IF NOT EXISTS `bible_books` (
  `id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `name` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `lookup` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `toc` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `print` varchar(6) COLLATE utf8_unicode_ci NOT NULL,
  `chapters` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `toc` (`toc`),
  UNIQUE KEY `print` (`print`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table timeless.bible_books: ~66 rows (approximately)
DELETE FROM `bible_books`;
/*!40000 ALTER TABLE `bible_books` DISABLE KEYS */;
INSERT INTO `bible_books` (`id`, `name`, `lookup`, `toc`, `print`, `chapters`) VALUES
	(1, 'Genesis', '|ge|gen|genesis|', 'Gen', 'Ge.', 50),
	(2, 'Exodus', '|e|ex|exo|exod|exodus|', 'Exo', 'Ex.', 40),
	(3, 'Leviticus', '|l|le|lev|leviticus|', 'Lev', 'Le.', 27),
	(4, 'Numbers', '|n|nu|num|numbers|', 'Num', 'Nu.', 36),
	(5, 'Deuteronomy', '|d|de|dt|deu|deut|deuteronomy|', 'Deu', 'Dt.', 34),
	(6, 'Joshua', '|jos|josh|joshua|', 'Jos', 'Jos.', 24),
	(7, 'Judges', '|jdg|jug|jdgs|judg|judges|', 'Jdg', 'Jdg.', 21),
	(8, 'Ruth', '|ru|rt|rut|ruth|', 'Rut', 'Rt.', 4),
	(9, '1 Samuel', '|1s|1 s|1sa|1 sa|1sm|1 sm|1sam|1 sam|1 samuel|1samuel|i samuel|', '1Sa', '1 Sa.', 31),
	(10, '2 Samuel', '|2s|2 s|2sa|2 sa|2sm|2 sm|2sam|2 sam|2 samuel|2samuel|ii samuel|', '2Sa', '2 Sa.', 24),
	(11, '1 Kings', '|1k|1 k|1ki|1 ki|1kin|1 kin|1kgs|1 kgs|1 kings|1kings|i kings|', '1Ki', '1 Ki.', 22),
	(12, '2 Kings', '|2k|2 k|2ki|2 ki|2kin|2 kin|2kgs|2 kgs|2 kings|2kings|ii kings|', '2Ki', '2 Ki.', 25),
	(13, '1 Chronicles', '|1c|1 c|1ch|1 ch|1chr|1 chr|1 chron|1 chronicles|1chronicles|i chronicles|', '1Chr', '1 Chr.', 29),
	(14, '2 Chronicles', '|2c|2 c|2ch|2 ch|2chr|2 chr|2 chron|2 chronicles|2chronicles|ii chronicles|', '2Chr', '2 Chr.', 36),
	(15, 'Ezra', '|ezr|ezra|', 'Ezr', 'Ezr.', 10),
	(16, 'Nehemiah', '|ne|neh|nehemiah|', 'Neh', 'Ne.', 13),
	(17, 'Esther', '|es|est|esth|esther|', 'Est', 'Es.', 10),
	(18, 'Job', '|jb|job|', 'Job', 'Job', 42),
	(19, 'Psalms', '|ps|psa|psm|psalm|psalms|', 'Psa', 'Ps.', 150),
	(20, 'Proverbs', '|pr|pro|prv|prov|proverbs|', 'Pro', 'Pr.', 31),
	(21, 'Ecclesiastes', '|ec|ecc|eccl|ecclesiastes|', 'Ecc', 'Ec.', 12),
	(22, 'Song of Solomon', '|s|so|sol|son|sng|song|ssol|song of songs|song of solomon|', 'Sng', 'So.', 8),
	(23, 'Isaiah', '|i|is|isa|isaiah|', 'Isa', 'Is.', 66),
	(24, 'Jeremiah', '|je|jer|jeremiah|', 'Jer', 'Je.', 52),
	(25, 'Lamentations', '|la|lam|lamentations|', 'Lam', 'La.', 5),
	(26, 'Ezekiel', '|ez|eze|ezek|ezekiel|', 'Eze', 'Eze.', 48),
	(27, 'Daniel', '|da|dn|dan|daniel|', 'Dan', 'Da.', 12),
	(28, 'Hosea', '|ho|hos|hosea|', 'Hos', 'Ho.', 14),
	(29, 'Joel', '|jl|joe|joel|', 'Joe', 'Joel', 3),
	(30, 'Amos', '|am|amo|amos|', 'Amo', 'Am.', 9),
	(31, 'Obadiah', '|o|ob|oba|obad|obadiah|', 'Oba', 'Ob.', 1),
	(32, 'Jonah', '|jon|jonah|', 'Jon', 'Jon.', 4),
	(33, 'Micah', '|mi|mic|micah|', 'Mic', 'Mi.', 7),
	(34, 'Nahum', '|na|nah|nahum|', 'Nah', 'Na.', 3),
	(35, 'Habakkuk', '|ha|hab|habakkuk|', 'Hab', 'Hab.', 3),
	(36, 'Zephaniah', '|zep|zeph|zephaniah|', 'Zep', 'Zep.', 3),
	(37, 'Haggai', '|hag|haggai|', 'Hag', 'Hag.', 2),
	(38, 'Zechariah', '|zec|zech|zechariah|', 'Zec', 'Zec.', 14),
	(39, 'Malachi', '|mal|malachi|', 'Mal', 'Mal.', 4),
	(40, 'Matthew', '|mt|mat|matt|matthew|', 'Mat', 'Mt.', 28),
	(41, 'Mark', '|mk|mar|mak|mark|', 'Mar', 'Mk.', 16),
	(42, 'Luke', '|lk|luk|luke|', 'Luk', 'Lk.', 24),
	(43, 'John', '|jn|joh|jhn|john|', 'Joh', 'Jn.', 21),
	(44, 'Acts', '|a|ac|act|acts|', 'Act', 'Ac.', 28),
	(45, 'Romans', '|ro|rom|romans|', 'Rom', 'Ro.', 16),
	(46, '1 Corinthians', '|1co|1 co|1cor|1 cor|1co|1 co|1 corinthians|1corinthians|i corinthians|', '1Co', '1 Co.', 16),
	(47, '2 Corinthians', '|2co|2 co|2cor|2 cor|2co|2 co|2 corinthians|2corinthians|ii corinthians|', '2Co', '2 Co.', 13),
	(48, 'Galatians', '|ga|gal|galatians|', 'Gal', 'Ga.', 6),
	(49, 'Ephesians', '|ep|eph|ephesians|', 'Eph', 'Ep.', 6),
	(50, 'Philippians', '|phi|phl|php|phil|philippians|', 'Php', 'Php.', 4),
	(51, 'Colossians', '|c|co|col|colossians|', 'Col', 'Co.', 4),
	(52, '1 Thessalonians', '|1th|1 th|1ts|1 ts|1thess|1 thess|1 thessalonians|1thessalonians|i thessalonians|', '1Th', '1 Th.', 5),
	(53, '2 Thessalonians', '|2th|2 th|2ts|2 ts|2thess|2 thess|2 thessalonians|2thessalonians|ii thessalonians|', '2Th', '2 Th.', 3),
	(54, '1 Timothy', '|1ti|1 ti|1tim|1 tim|1 timothy|1timothy|i timothy|', '1Ti', '1 Ti.', 6),
	(55, '2 Timothy', '|2ti|2 ti|2tim|2 tim|2 timothy|2timothy|ii timothy|', '2Ti', '2 Ti.', 4),
	(56, 'Titus', '|t|ti|tit|titus|', 'Tit', 'Ti.', 3),
	(57, 'Philemon', '|phm|phlm|phmn|phile|philemon|', 'Phm', 'Phm.', 1),
	(58, 'Hebrews', '|he|heb|hebrews|', 'Heb', 'He.', 13),
	(59, 'James', '|ja|jam|jas|james|', 'Jam', 'Ja.', 5),
	(60, '1 Peter', '|1p|1 p|1pe|1 pe|1pt|1 pt|1pet|1 pet|1 peter|1peter|i peter|', '1Pe', '1 Pe.', 5),
	(61, '2 Peter', '|2p|2 p|2pe|2 pe|2pt|2 pt|2pet|2 pet|2 peter|2peter|ii peter|', '2Pe', '2 Pe.', 3),
	(62, '1 John', '|1j|1 j|1Jn|1 jn|1jo|1 jo|1john|1 john|i john|', '1Jn', '1 Jn.', 5),
	(63, '2 John', '|2j|2 j|2jn|2 jn|2jo|2 jo|2john|2 john|ii john|', '2Jn', '2 Jn.', 1),
	(64, '3 John', '|3j|3 j|3jn|3 jn|3jo|3 jo|3john|3 john|iii john|', '3Jn', '3 Jn.', 1),
	(65, 'Jude', '|jud|jude|', 'Jud', 'Jude', 1),
	(66, 'Revelation', '|re|rev|revelation|revelations|', 'Rev', 'Re.', 22);
/*!40000 ALTER TABLE `bible_books` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
